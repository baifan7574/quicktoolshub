import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: "QuickToolsHub - Free Online Tools",
    template: "%s | QuickToolsHub",
  },
  description: "Free online tools for PDF, Image, Text, and more. Quick & Easy Solutions.",
  keywords: ["free online tools", "PDF tools", "image tools", "text tools", "developer tools", "online utilities"],
  authors: [{ name: "QuickToolsHub" }],
  creator: "QuickToolsHub",
  publisher: "QuickToolsHub",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'https://quicktoolshub.com'),
  openGraph: {
    type: "website",
    locale: "en_US",
    url: process.env.NEXT_PUBLIC_APP_URL || 'https://quicktoolshub.com',
    siteName: "QuickToolsHub",
    title: "QuickToolsHub - Free Online Tools",
    description: "Free online tools for PDF, Image, Text, and more. Quick & Easy Solutions.",
  },
  twitter: {
    card: "summary_large_image",
    title: "QuickToolsHub - Free Online Tools",
    description: "Free online tools for PDF, Image, Text, and more. Quick & Easy Solutions.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased flex flex-col min-h-screen`}
      >
        <Header />
        <main className="flex-grow">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}
