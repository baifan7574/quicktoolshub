# 如何获取Supabase API Keys

## 📍 API Keys位置

API Keys不在General设置页面，而是在**API Keys**页面。

## 🔑 获取API Keys的步骤

### 步骤1：进入API Keys页面

1. 在Supabase Dashboard左侧边栏，找到 **Settings**
2. 在 **PROJECT SETTINGS** 下，点击 **API Keys**
3. 或者直接访问：`https://supabase.com/dashboard/project/nbfzhxgkfljeuoncujum/settings/api`

### 步骤2：找到需要的Keys

在API Keys页面，您会看到：

#### 1. Project URL
- **位置**：页面顶部
- **格式**：`https://nbfzhxgkfljeuoncujum.supabase.co`
- **用途**：用于连接Supabase

#### 2. anon public key（公开密钥）
- **位置**：在"Project API keys"部分
- **标签**：`anon` `public`
- **格式**：`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`
- **用途**：客户端使用（前端）
- **安全性**：可以公开，但有Row Level Security保护

#### 3. service_role key（服务密钥）
- **位置**：在"Project API keys"部分
- **标签**：`service_role` `secret`
- **格式**：`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`
- **用途**：服务端使用（后端）
- **安全性**：**保密！不要公开！**

### 步骤3：复制Keys

1. 点击每个key旁边的 **"Copy"** 按钮
2. 保存到安全的地方（稍后需要用到）

## 📋 需要获取的信息清单

- [ ] **Project URL**：`https://nbfzhxgkfljeuoncujum.supabase.co`
- [ ] **anon public key**：`eyJhbGc...`（公开密钥）
- [ ] **service_role key**：`eyJhbGc...`（服务密钥，保密）

## ⚠️ 重要提示

1. **service_role key是保密的**：
   - 不要提交到Git
   - 不要在前端代码中使用
   - 只在服务器端使用

2. **anon public key可以公开**：
   - 可以在前端代码中使用
   - 有Row Level Security保护

3. **Project ID**：
   - 您已经找到了：`nbfzhxgkfljeuoncujum`
   - 这个ID会用在Project URL中

## 🔗 快速访问链接

直接访问API Keys页面：
```
https://supabase.com/dashboard/project/nbfzhxgkfljeuoncujum/settings/api
```

或者：
1. 在Dashboard左侧点击 **Settings**
2. 在 **PROJECT SETTINGS** 下点击 **API Keys**

