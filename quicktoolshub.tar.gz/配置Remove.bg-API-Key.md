# 配置 Remove.bg API Key

## ✅ 已完成的工作

1. **创建了后端 API** (`app/api/remove-background/route.ts`)
   - 在服务器端处理背景移除
   - API Key 存储在服务器端，用户无需输入

2. **简化了前端组件**
   - 移除了 API Key 输入框
   - 移除了相关说明
   - 用户只需上传图片即可使用

---

## 🔧 配置步骤

### 1. 获取 Remove.bg API Key

1. 访问：https://www.remove.bg/api
2. 注册账号（免费）
3. 获取 API Key（免费版：每月 50 张图片）

### 2. 配置环境变量

在 `.env.local` 文件中添加：

```env
# Remove.bg API Key（服务器端使用）
REMOVE_BG_API_KEY=your_api_key_here
```

**或者**（如果上面的不工作，也可以使用）：

```env
NEXT_PUBLIC_REMOVE_BG_API_KEY=your_api_key_here
```

### 3. 重启开发服务器

```bash
# 停止当前服务器（Ctrl+C）
# 然后重新启动
npm run dev
```

---

## 📝 注意事项

1. **API Key 安全**
   - API Key 存储在服务器端（`.env.local`）
   - 不会暴露给客户端
   - 用户无法看到或修改

2. **免费额度**
   - 免费版：每月 50 张图片
   - 如果超出，需要升级账户

3. **错误处理**
   - 如果 API Key 未配置，会显示友好的错误提示
   - 如果额度用完，会提示用户稍后再试

---

## ✅ 完成

配置完成后，用户就可以：
- ✅ 直接上传图片
- ✅ 无需输入任何 API Key
- ✅ 一键移除背景
- ✅ 简单高效！

---

## 🎯 测试

1. 配置 API Key（在 `.env.local` 中）
2. 重启开发服务器
3. 访问 `/tools/background-remover`
4. 上传图片测试

现在工具应该非常简单易用了！

