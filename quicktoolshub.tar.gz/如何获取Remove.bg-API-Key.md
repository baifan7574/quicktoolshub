# 如何获取 Remove.bg API Key

## 🎯 快速步骤

### 1. 访问 Remove.bg API 页面
打开：https://www.remove.bg/api

### 2. 注册/登录账号
- 如果没有账号，点击 "Sign Up" 注册
- 如果已有账号，直接登录

### 3. 获取 API Key
- 登录后，进入 API 页面
- 找到 "API Key" 部分
- 复制你的 API Key

### 4. 配置到项目中

**方法1：使用批处理脚本（推荐）**
1. 双击运行：`快速配置Remove.bg-API-Key.bat`
2. 输入你的 API Key
3. 按回车完成

**方法2：手动配置**
1. 打开文件：`D:\quicktoolshub\.env.local`
2. 找到这一行：
   ```
   REMOVE_BG_API_KEY=your_api_key_here
   ```
3. 将 `your_api_key_here` 替换为你的实际 API Key
4. 保存文件

### 5. 重启开发服务器
```bash
# 停止当前服务器（Ctrl+C）
npm run dev
```

---

## 📝 免费额度

- **免费版**：每月 50 张图片
- **付费版**：根据套餐不同，有更多额度

---

## ✅ 完成

配置完成后，背景移除工具就可以直接使用了！

