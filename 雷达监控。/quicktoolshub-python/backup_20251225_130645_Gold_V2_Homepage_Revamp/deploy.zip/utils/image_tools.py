try:
    from rembg import remove
    from PIL import Image
    REMBG_AVAILABLE = True
except Exception as e:
    print(f"Warning: rembg or onnxruntime not available due to environment issues: {e}")
    REMBG_AVAILABLE = False
    
import io
import os
from config import Config

def remove_background(input_path):
    """
    移除图片背景 (带有环境兼容性处理)
    """
    if not REMBG_AVAILABLE:
        raise Exception("AI 处理环境暂未准备就绪 (ONNX/Numpy 冲突)，请稍后再试或联系管理员修复环境。")
        
    try:
        # 1. 打开图片
        with open(input_path, 'rb') as i:
            input_data = i.read()
            
        output_data = remove(input_data)
        
        filename = os.path.basename(input_path)
        name, _ = os.path.splitext(filename)
        output_filename = f"{name}_no-bg.png"
        output_path = os.path.join(Config.UPLOAD_FOLDER, output_filename)
        
        with open(output_path, 'wb') as o:
            o.write(output_data)
            
        return output_path

    except Exception as e:
        print(f"Error processing image {input_path}: {str(e)}")
        raise Exception(f"背景移除处理失败: {str(e)}")

