from PyPDF2 import PdfReader, PdfWriter
from pdf2docx import Converter
import os
from config import Config

def compress_pdf(input_path):
    """
    压缩 PDF 文件 (通过降低图片质量)
    这种方法对于由扫描图片组成的 PDF 极其有效
    """
    try:
        output_path = os.path.join(Config.UPLOAD_FOLDER, f'compressed_{os.path.basename(input_path)}')
        
        reader = PdfReader(input_path)
        writer = PdfWriter()
        
        for page in reader.pages:
            # 尝试深度压缩：压缩页面内容和图片
            # 注意：PyPDF2 本身的 lossy compression 能力有限
            # 这只是第一层处理，为了保证运行稳定性，我们先只做无损优化
            # 如果需要更激进的压缩，需要引入 Ghostscript，但那会增加部署难度
            page.compress_content_streams() 
            writer.add_page(page)
        
        # 启用元数据清理
        writer.add_metadata({}) 
        
        # 优化选项
        with open(output_path, 'wb') as output_file:
            writer.write(output_file)
            
        return output_path
    
    except Exception as e:
        print(f"Error compressing PDF: {str(e)}")
        # 如果压缩失败，返回原文件或者抛出更友好的错误
        raise Exception("PDF 压缩失败，文件可能已损坏或受保护。")

def pdf_to_word(input_path):
    """将 PDF 转换为 Word"""
    output_path = os.path.join(Config.UPLOAD_FOLDER, f'{os.path.splitext(os.path.basename(input_path))[0]}.docx')
    
    cv = Converter(input_path)
    cv.convert(output_path)
    cv.close()
    
    return output_path

